function buscarProducto() {
    let query = document.getElementById("searchQuery").value;
    let priceFilter = document.getElementById("priceFilter").value;
    
    if (query.trim() === "") {
        alert("Por favor, escribe algo para buscar.");
        return;
    }

    let amazonUrl = `https://www.amazon.com/s?k=${encodeURIComponent(query)}`;
    let aliexpressUrl = `https://www.aliexpress.com/wholesale?SearchText=${encodeURIComponent(query)}`;
    let wallapopUrl = `https://es.wallapop.com/search?keywords=${encodeURIComponent(query)}`;
    let backmarketUrl = `https://www.backmarket.com/en-us/l?q=${encodeURIComponent(query)}`;
    let ebayUrl = `https://www.ebay.com/sch/i.html?_nkw=${encodeURIComponent(query)}`;

    // Si se selecciona el filtro de precio, añade la ordenación correspondiente
    if (priceFilter === "low") {
        amazonUrl += "&s=price-asc-rank";
        aliexpressUrl += "&orderby=price_asc";
        ebayUrl += "&_sop=12"; // eBay: más bajo primero
    } else if (priceFilter === "high") {
        amazonUrl += "&s=price-desc-rank";
        aliexpressUrl += "&orderby=price_desc";
        ebayUrl += "&_sop=13"; // eBay: más alto primero
    }

    // Actualiza los enlaces con las URLs de búsqueda filtradas
    document.getElementById("amazonLink").href = amazonUrl;
    document.getElementById("aliexpressLink").href = aliexpressUrl;
    document.getElementById("wallapopLink").href = wallapopUrl;
    document.getElementById("backmarketLink").href = backmarketUrl;
    document.getElementById("ebayLink").href = ebayUrl;
}
function buscarProducto() {
    let query = document.getElementById("searchQuery").value;
    let priceFilter = document.getElementById("priceFilter").value;

    if (query.trim() === "") {
        alert("Por favor, escribe algo para buscar.");
        return;
    }

    // Crear las URLs de búsqueda
    let amazonUrl = `https://www.amazon.com/s?k=${encodeURIComponent(query)}`;
    let aliexpressUrl = `https://www.aliexpress.com/wholesale?SearchText=${encodeURIComponent(query)}`;
    let wallapopUrl = `https://es.wallapop.com/search?keywords=${encodeURIComponent(query)}`;
    let backmarketUrl = `https://www.backmarket.com/en-us/l?q=${encodeURIComponent(query)}`;
    let ebayUrl = `https://www.ebay.com/sch/i.html?_nkw=${encodeURIComponent(query)}`;

    // Filtros de precio
    if (priceFilter === "low") {
        amazonUrl += "&s=price-asc-rank";
        aliexpressUrl += "&orderby=price_asc";
        ebayUrl += "&_sop=12"; // eBay: más bajo primero
    } else if (priceFilter === "high") {
        amazonUrl += "&s=price-desc-rank";
        aliexpressUrl += "&orderby=price_desc";
        ebayUrl += "&_sop=13"; // eBay: más alto primero
    }

    // Actualiza los enlaces con las URLs de búsqueda filtradas
    document.getElementById("amazonLink").href = amazonUrl;
    document.getElementById("aliexpressLink").href = aliexpressUrl;
    document.getElementById("wallapopLink").href = wallapopUrl;
    document.getElementById("backmarketLink").href = backmarketUrl;
    document.getElementById("ebayLink").href = ebayUrl;

    // Guardar en historial de búsqueda
    let historyList = document.getElementById("searchHistory");
    let listItem = document.createElement("li");
    listItem.textContent = `Buscando "${query}"`;
    let link = document.createElement("a");
    link.href = amazonUrl;
    link.textContent = "Ver resultados en Amazon";
    link.target = "_blank";
    listItem.appendChild(link);
    historyList.appendChild(listItem);
}
// Función para cargar el historial guardado
function cargarHistorial() {
    let historialGuardado = localStorage.getItem("searchHistory");
    if (historialGuardado) {
        document.getElementById("searchHistory").innerHTML = historialGuardado;
    }
}

// Función para guardar en LocalStorage y mostrar el historial
function buscarProducto() {
    let query = document.getElementById("searchQuery").value;
    let priceFilter = document.getElementById("priceFilter").value;

    if (query.trim() === "") {
        alert("Por favor, escribe algo para buscar.");
        return;
    }

    // Crear las URLs de búsqueda
    let amazonUrl = `https://www.amazon.com/s?k=${encodeURIComponent(query)}`;
    let aliexpressUrl = `https://www.aliexpress.com/wholesale?SearchText=${encodeURIComponent(query)}`;
    let wallapopUrl = `https://es.wallapop.com/search?keywords=${encodeURIComponent(query)}`;
    let backmarketUrl = `https://www.backmarket.com/en-us/l?q=${encodeURIComponent(query)}`;
    let ebayUrl = `https://www.ebay.com/sch/i.html?_nkw=${encodeURIComponent(query)}`;

    // Filtros de precio
    if (priceFilter === "low") {
        amazonUrl += "&s=price-asc-rank";
        aliexpressUrl += "&orderby=price_asc";
        ebayUrl += "&_sop=12"; // eBay: más bajo primero
    } else if (priceFilter === "high") {
        amazonUrl += "&s=price-desc-rank";
        aliexpressUrl += "&orderby=price_desc";
        ebayUrl += "&_sop=13"; // eBay: más alto primero
    }

    // Actualiza los enlaces con las URLs de búsqueda filtradas
    document.getElementById("amazonLink").href = amazonUrl;
    document.getElementById("aliexpressLink").href = aliexpressUrl;
    document.getElementById("wallapopLink").href = wallapopUrl;
    document.getElementById("backmarketLink").href = backmarketUrl;
    document.getElementById("ebayLink").href = ebayUrl;

    // Crear un nuevo elemento de historial de búsqueda
    let history
    function buscarProducto() {
    let query = document.getElementById("searchQuery").value;
    let priceFilter = document.getElementById("priceFilter").value;

    if (query.trim() === "") {
        alert("Por favor, escribe algo para buscar.");
        return;
    }

    // Mostrar el spinner mientras se buscan los productos
    document.getElementById("loading").style.display = "block";

    // Crear las URLs de búsqueda
    let amazonUrl = `https://www.amazon.com/s?k=${encodeURIComponent(query)}`;
    let aliexpressUrl = `https://www.aliexpress.com/wholesale?SearchText=${encodeURIComponent(query)}`;
    let wallapopUrl = `https://es.wallapop.com/search?keywords=${encodeURIComponent(query)}`;
    let backmarketUrl = `https://www.backmarket.com/en-us/l?q=${encodeURIComponent(query)}`;
    let ebayUrl = `https://www.ebay.com/sch/i.html?_nkw=${encodeURIComponent(query)}`;

    // Filtros de precio
    if (priceFilter === "low") {
        amazonUrl += "&s=price-asc-rank";
        aliexpressUrl += "&orderby=price_asc";
        ebayUrl += "&_sop=12"; // eBay: más bajo primero
    } else if (priceFilter === "high") {
        amazonUrl += "&s=price-desc-rank";
        aliexpressUrl += "&orderby=price_desc";
        ebayUrl += "&_sop=13"; // eBay: más alto primero
    }

    // Actualiza los enlaces con las URLs de búsqueda filtradas
    document.getElementById("amazonLink").href = amazonUrl;
    document.getElementById("aliexpressLink").href = aliexpressUrl;
    document.getElementById("wall
                            function buscarProducto() {
    let query = document.getElementById("searchQuery").value;
    let priceFilter = document.getElementById("priceFilter").value;
    let categoryFilter = document.getElementById("categoryFilter").value;
    let brandFilter = document.getElementById("brandFilter").value;

    if (query.trim() === "") {
        alert("Por favor, escribe algo para buscar.");
        return;
    }

    // Crear las URLs de búsqueda
    let amazonUrl = `https://www.amazon.com/s?k=${encodeURIComponent(query)}`;
    let aliexpressUrl = `https://www.aliexpress.com/wholesale?SearchText=${encodeURIComponent(query)}`;
    let wallapopUrl = `https://es.wallapop.com/search?keywords=${encodeURIComponent(query)}`;
    let backmarketUrl = `https://www.backmarket.com/en-us/l?q=${encodeURIComponent(query)}`;
    let ebayUrl = `https://www.ebay.com/sch/i.html?_nkw=${encodeURIComponent(query)}`;

    // Filtros de precio
    if (priceFilter === "low") {
        amazonUrl += "&s=price-asc-rank";
        aliexpressUrl += "&orderby=price_asc";
        ebayUrl += "&_
      function buscarProducto() {
    let query = document.getElementById("searchQuery").value;
    let suggestionsContainer = document.getElementById("suggestionsContainer");
    let suggestionsList = document.getElementById("suggestionsList");

    // Mostrar o esconder el contenedor de sugerencias
    if (query.trim() === "") {
        suggestionsContainer.style.display = "none";
        return;
    } else {
        suggestionsContainer.style.display = "block";
    }

    // Crear las URLs de búsqueda
    let amazonUrl = `https://www.amazon.com/s?k=${encodeURIComponent(query)}`;
    let aliexpressUrl = `https://www.aliexpress.com/wholesale?SearchText=${encodeURIComponent(query)}`;

    // Simulamos algunas sugerencias (en una búsqueda real, usaríamos una API de sugerencias)
    let suggestions = [
        { name: "Producto 1", url: amazonUrl },
        { name: "Producto 2", url: aliexpressUrl },
        { name: "Producto 3",
         let favoritos = JSON.parse(localStorage.getItem("favoritos")) || [];

function agregarAFavoritos() {
    let producto = {
        nombre: document.getElementById("searchQuery").value,
        url: document.getElementById("amazonLink").href
    };

    favoritos.push(producto);
    localStorage.setItem("favoritos", JSON.stringify(favoritos));

    alert("Producto añadido a favoritos");
}

function mostrarFavoritos() {
    let favoritosList = document.getElementById("favoritosList");
    favoritosList.innerHTML = ""; // Limpiar la lista

    favoritos.forEach(favorito => {
        let listItem = document.createElement("li");
        let link = document.createElement("a");
        link.href = favorito.url;
        link.textContent = favorito.nombre;
        listItem.appendChild(link);
        favoritosList.appendChild(listItem);
    });
}
        let comentarios = JSON.parse(localStorage.getItem("comentarios")) || [];

function guardarComentario() {
    let comentario = document.getElementById("commentText").value;
    if (comentario.trim() === "") {
        alert("Por favor, escribe un comentario.");
        return;
    }

    comentarios.push(comentario);
    localStorage.setItem("comentarios", JSON.stringify(comentarios));

    alert("Gracias por tu comentario");

    mostrarComentarios();
}

function mostrarComentarios() {
    let commentsList = document.getElementById("commentsList");
    commentsList.innerHTML = ""; // Limpiar los comentarios previos

    comentarios.forEach(comentario => {
        let listItem = document.createElement("li");
        listItem.textContent = comentario;
        commentsList.appendChild(listItem);
    });
}
        document.querySelectorAll('a').forEach(function(anchor) {
  anchor.addEventListener('click', function(e) {
    if (!anchor.href.startsWith('https://')) {
      alert('Este enlace no es seguro');
      e.preventDefault();
    }
  });
});
        // Ejemplo simple para evitar que se inserten etiquetas HTML en comentarios
function sanitizeInput(input) {
  return input.replace(/<[^>]*>/g, ''); // Elimina las etiquetas HTML
}
        